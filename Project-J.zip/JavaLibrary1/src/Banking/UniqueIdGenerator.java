/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Banking;
import java.util.Random;

/**
 *
 * @author Pc
 */
public class UniqueIdGenerator {
   

    
    public static String generateUniqueID() {
        Random random = new Random();//generates random number
        StringBuffer uniqueID = new StringBuffer();
        
        int firstDigit = random.nextInt(9) + 1;
        uniqueID.append(firstDigit);
        
        while (uniqueID.length() < 10) {
            int randomNumber = random.nextInt(10); // Generate a random number between 0 and 9
            uniqueID.append(randomNumber);//Concatenate the generated number with previous number
        }
        
        return uniqueID.toString();
        
    }
    
}

