/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Banking;

import java.util.Random;

public class TransactionIdGenerator {

    public static String generateTransactionID() {
        
        int randomNumber = new Random().nextInt(9000) + 1000;
        String transactionId = String.valueOf(randomNumber);
        return transactionId;
    }
}
